//
//  PlayerSelectionView.swift
//  BIGHDOOKIE
//
//  Created by Bobby Smith on 10/31/24.
//

import SwiftUI
import AVFoundation
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseCrashlytics
import FirebaseFunctions
import FirebaseMessaging

struct PlayerSelectionView: View {
    @State private var selectedHumanPlayers = 1 // Start with 1 human player
    @State private var selectedComputerPlayers = 1 // Start with 1 computer player
    @State private var selectedAILevel: String = "Normal" // AI level for difficulty
    @State private var isGameReady = false
    @ObservedObject var gameSession = GameSession()

    // Player Avatars
    @State private var humanAvatars = [String](repeating: "person.fill", count: 4)
    @State private var aiAvatars = ["cpu", "robot.fill", "tv", "antenna.radiowaves.left.and.right"]
    
    let aiDifficultyLevels = ["Easy", "Normal", "Hard"] // AI Difficulty levels
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Background with gradient
                LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack(spacing: 40) {
                    // Title
                    Text("Player Selection")
                        .font(.system(size: 40, design: .rounded))
                        .foregroundColor(.white)
                        .shadow(color: .black, radius: 5, x: 2, y: 2)
                        .padding(.top, 40)

                    // Player Count Settings
                    HStack(spacing: 20) {
                        // Human Player Count
                        VStack {
                            Text("Human Players: \(selectedHumanPlayers)")
                                .foregroundColor(.white)
                                .font(.title2)

                            Stepper("", value: $selectedHumanPlayers, in: 1...100)
                                .labelsHidden()
                                .onChange(of: selectedHumanPlayers) {
                                    adjustComputerPlayers()
                                }
                        }

                        // Computer Player Count
                        VStack {
                            Text("Computer Players: \(selectedComputerPlayers)")
                                .foregroundColor(.white)
                                .font(.title2)

                            Stepper("", value: $selectedComputerPlayers, in: 0...100)
                                .labelsHidden()
                                .onChange(of: selectedComputerPlayers) {
                                    adjustComputerPlayers()
                                }
                        }
                    }

                    // AI Difficulty Level Picker
                    Picker("AI Difficulty", selection: $selectedAILevel) {
                        ForEach(aiDifficultyLevels, id: \.self) {
                            Text($0)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()
                    .background(Color.white.opacity(0.2))
                    .cornerRadius(10)
                    .shadow(radius: 10)

                    // Avatars for Human and AI Players
                    HStack {
                        ForEach(0..<selectedHumanPlayers, id: \.self) { index in
                            Image(systemName: humanAvatars[index % humanAvatars.count])
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.white)
                                .padding()
                        }

                        ForEach(0..<selectedComputerPlayers, id: \.self) { index in
                            Image(systemName: aiAvatars[index % aiAvatars.count])
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.white)
                                .padding()
                        }
                    }

                    // Start Game Button
                    Button(action: {
                        startGame()
                    }) {
                        Text("Start Game")
                            .bold()
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.yellow]), startPoint: .leading, endPoint: .trailing))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(radius: 10)
                    }
                    .padding()

                    Spacer()
                }
                .padding()
            }
            // Navigation to ContentView when the game is ready
            .navigationDestination(isPresented: $isGameReady) {
                ContentView(numberOfHumanPlayers: selectedHumanPlayers, numberOfComputerPlayers: selectedComputerPlayers, gameSession: gameSession)
            }
        }
    }

    // Adjust the computer players count to ensure at least one computer player if there is only one human player
    private func adjustComputerPlayers() {
        if selectedHumanPlayers == 1 && selectedComputerPlayers == 0 {
            selectedComputerPlayers = 1
        }
    }

    // Logic to set up the game and save the session to Firestore
    private func startGame() {
        // Add players to the session
        for index in 1...selectedHumanPlayers {
            gameSession.addPlayer(name: "Player \(index)", isComputer: false)
        }

        for index in 1...selectedComputerPlayers {
            gameSession.addPlayer(name: "Computer \(index)", isComputer: true)
        }

        // Save the session to Firestore
        gameSession.saveSession()

        // Start listening to the session for updates
        gameSession.listenToSession(sessionID: gameSession.sessionID!)

        // Mark the game as ready and navigate to the game view
        isGameReady = true
    }
}
