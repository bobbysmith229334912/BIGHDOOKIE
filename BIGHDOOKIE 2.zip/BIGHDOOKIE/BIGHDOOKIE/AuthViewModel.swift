import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseCrashlytics
import FirebaseFunctions
import FirebaseMessaging


class AuthViewModel: ObservableObject {
    @Published var isLoggedIn = false
    @Published var isLoading = true

    init() {
        checkLoginStatus()
    }

    // Check if the user is logged in or not
    func checkLoginStatus() {
        Auth.auth().addStateDidChangeListener { [weak self] _, user in
            DispatchQueue.main.async {
                self?.isLoading = false // Firebase has responded
                if let _ = user {
                    self?.isLoggedIn = true
                } else {
                    self?.isLoggedIn = false
                }
            }
        }
    }

    // Login function
    func login(email: String, password: String, completion: @escaping (String?) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(error.localizedDescription)
            } else {
                DispatchQueue.main.async {
                    self.isLoggedIn = true
                }
                completion(nil)
            }
        }
    }

    // Register function with displayName
    func register(email: String, password: String, username: String, completion: @escaping (String?) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(error.localizedDescription)
            } else if let user = result?.user {
                // Update the display name in Firebase Auth profile
                let changeRequest = user.createProfileChangeRequest()
                changeRequest.displayName = username
                changeRequest.commitChanges { error in
                    if let error = error {
                        completion("Error updating profile: \(error.localizedDescription)")
                    } else {
                        // Save user data in Firestore
                        let db = Firestore.firestore()
                        let userRef = db.collection("users").document(user.uid)
                        userRef.setData([
                            "email": email,
                            "displayName": username, // Save the username
                            "createdAt": Timestamp()
                        ]) { err in
                            if let err = err {
                                completion("Error saving user data: \(err.localizedDescription)")
                            } else {
                                DispatchQueue.main.async {
                                    self.isLoggedIn = true
                                }
                                completion(nil)
                            }
                        }
                    }
                }
            }
        }
    }

    // Logout function
    func logout() {
        do {
            try Auth.auth().signOut()
            DispatchQueue.main.async {
                self.isLoggedIn = false
            }
        } catch let signOutError as NSError {
            print("Error signing out: \(signOutError)")
        }
    }
}
