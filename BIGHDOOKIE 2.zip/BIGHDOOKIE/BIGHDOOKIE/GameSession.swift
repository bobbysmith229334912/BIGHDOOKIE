import Foundation
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseCrashlytics
import FirebaseFunctions
import FirebaseMessaging


class GameSession: ObservableObject {
    @Published var players: [Player] = [] // Stores the players in the session
    @Published var sessionID: String? // Unique ID for the session
    @Published var currentTurnPlayerID: String? // Track the current player's turn
    private let db = Firestore.firestore() // Firestore reference

    init() {
        // Generate a session ID when the game session is created
        self.sessionID = UUID().uuidString
    }

    // Function to add players (either human or AI)
    func addPlayer(name: String, isComputer: Bool = false) {
        let player = Player(name: name, isComputer: isComputer)
        players.append(player)
        saveSession() // Update Firestore immediately when a player is added
    }

    // Save session data to Firestore manually
    func saveSession() {
        guard let sessionID = sessionID else { return }

        let playerData = players.map { player -> [String: Any] in
            return [
                "name": player.name,
                "bankroll": player.bankroll,
                "isComputer": player.isComputer,
                "hand": player.hand.map { ["rank": $0.rank, "suit": $0.suit] }
            ]
        }

        let sessionData: [String: Any] = [
            "sessionID": sessionID,
            "players": playerData,
            "currentTurnPlayerID": players.first?.id.uuidString ?? "" // Set the first player's turn
        ]

        db.collection("gameSessions").document(sessionID).setData(sessionData) { error in
            if let error = error {
                print("Error saving session: \(error.localizedDescription)")
            } else {
                print("Session successfully saved.")
            }
        }
    }

    // Fetch session data from Firestore manually
    func fetchSession(sessionID: String) {
        let docRef = db.collection("gameSessions").document(sessionID)
        docRef.getDocument { document, error in
            if let document = document, document.exists {
                if let data = document.data() {
                    self.sessionID = data["sessionID"] as? String
                    self.currentTurnPlayerID = data["currentTurnPlayerID"] as? String
                    if let playersData = data["players"] as? [[String: Any]] {
                        self.players = playersData.map { playerDict in
                            let name = playerDict["name"] as? String ?? ""
                            let bankroll = playerDict["bankroll"] as? Double ?? 0.0
                            let isComputer = playerDict["isComputer"] as? Bool ?? false
                            let handData = playerDict["hand"] as? [[String: String]] ?? []
                            let hand = handData.compactMap { dict -> Card? in
                                guard let rank = dict["rank"], let suit = dict["suit"] else { return nil }
                                return Card(rank: rank, suit: suit)
                            }
                            let player = Player(name: name, bankroll: bankroll, isComputer: isComputer)
                            player.hand = hand
                            return player
                        }
                    }
                }
            } else {
                print("Document does not exist: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }

    // Listen to session changes (real-time sync)
    func listenToSession(sessionID: String) {
        let docRef = db.collection("gameSessions").document(sessionID)

        docRef.addSnapshotListener { documentSnapshot, error in
            guard let document = documentSnapshot else {
                print("Error fetching session updates: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            if let data = document.data() {
                self.sessionID = data["sessionID"] as? String
                self.currentTurnPlayerID = data["currentTurnPlayerID"] as? String
                if let playersData = data["players"] as? [[String: Any]] {
                    self.players = playersData.map { playerDict in
                        let name = playerDict["name"] as? String ?? ""
                        let bankroll = playerDict["bankroll"] as? Double ?? 0.0
                        let isComputer = playerDict["isComputer"] as? Bool ?? false
                        let handData = playerDict["hand"] as? [[String: String]] ?? []
                        let hand = handData.compactMap { dict -> Card? in
                            guard let rank = dict["rank"], let suit = dict["suit"] else { return nil }
                            return Card(rank: rank, suit: suit)
                        }
                        let player = Player(name: name, bankroll: bankroll, isComputer: isComputer)
                        player.hand = hand
                        return player
                    }
                }
            }
        }
    }

    // Update the session to move to the next player's turn
    func updateTurn(for nextPlayerID: String) {
        guard let sessionID = sessionID else { return }

        db.collection("gameSessions").document(sessionID).updateData([
            "currentTurnPlayerID": nextPlayerID
        ]) { error in
            if let error = error {
                print("Error updating turn: \(error.localizedDescription)")
            } else {
                print("Turn updated successfully.")
            }
        }
    }

    // Move to the next player's turn automatically
    func moveToNextTurn() {
        guard let currentPlayerID = currentTurnPlayerID, !players.isEmpty else { return }
        
        if let currentIndex = players.firstIndex(where: { $0.id.uuidString == currentPlayerID }) {
            let nextIndex = (currentIndex + 1) % players.count
            let nextPlayerID = players[nextIndex].id.uuidString
            updateTurn(for: nextPlayerID)
        }
    }
}
