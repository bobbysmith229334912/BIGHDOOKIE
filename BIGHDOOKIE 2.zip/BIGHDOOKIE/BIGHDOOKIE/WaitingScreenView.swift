import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseCrashlytics
import FirebaseFunctions
import FirebaseMessaging


struct WaitingScreenView: View {
    var sessionID: String
    var selectedUsers: Set<String>
    @ObservedObject var gameSession: GameSession
    @Binding var navigateToGame: Bool
    @State private var readyUsers: Set<String> = [] // Users who pressed "Join"
    @State private var errorMessage: String?

    var body: some View {
        VStack {
            Text("Waiting for Players to Join...")
                .font(.headline)
                .padding()

            // Display the list of selected users with join status
            List(selectedUsers.sorted(), id: \.self) { user in
                HStack {
                    Text(user)
                    Spacer()
                    if readyUsers.contains(user) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                    }
                }
            }

            // Button to allow the current player to join
            Button(action: {
                markPlayerAsJoined()
            }) {
                Text("Join")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()

            // Error message display
            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }

            Spacer()
        }
        .onAppear {
            listenToJoinStatus()
        }
    }

    // Mark the current player as "joined"
    private func markPlayerAsJoined() {
        let db = Firestore.firestore()
        let sessionRef = db.collection("gameSessions").document(sessionID)

        sessionRef.getDocument { document, error in
            if let document = document, document.exists {
                if let sessionData = document.data() {
                    var players = sessionData["players"] as? [[String: Any]] ?? []

                    // Update the current player's "hasJoined" status
                    if let index = players.firstIndex(where: { $0["uid"] as? String == Auth.auth().currentUser?.uid }) {
                        players[index]["hasJoined"] = true
                    }

                    sessionRef.updateData(["players": players]) { error in
                        if let error = error {
                            self.errorMessage = "Error marking as joined: \(error.localizedDescription)"
                        }
                    }
                }
            }
        }
    }

    // Listen for join status changes from Firestore
    private func listenToJoinStatus() {
        let db = Firestore.firestore()
        db.collection("gameSessions").document(sessionID).addSnapshotListener { documentSnapshot, error in
            guard let document = documentSnapshot, document.exists else {
                print("Error fetching game state: \(String(describing: error))")
                return
            }

            let gameData = document.data() ?? [:]
            let players = gameData["players"] as? [[String: Any]] ?? []

            // Update the list of ready users
            readyUsers = Set(players.compactMap { player in
                if let hasJoined = player["hasJoined"] as? Bool, hasJoined {
                    return player["name"] as? String
                }
                return nil
            })

            // Automatically navigate to the game once all players have joined
            let humanPlayers = players.filter { !($0["isComputer"] as? Bool ?? false) }
            if readyUsers.count == humanPlayers.count {
                DispatchQueue.main.async {
                    navigateToGame = true
                }
            }
        }
    }
}
