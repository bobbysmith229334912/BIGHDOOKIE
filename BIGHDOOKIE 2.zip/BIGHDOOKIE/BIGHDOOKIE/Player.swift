import Foundation
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseCrashlytics
import FirebaseFunctions
import FirebaseMessaging


// Player class representing a game player
class Player: Identifiable {
    var id = UUID() // Unique identifier for each player
    var name: String
    var bankroll: Double
    var isComputer: Bool // To track if the player is a computer
    var hand: [Card] = [] // The player's hand of cards

    init(name: String, bankroll: Double = 1000.0, isComputer: Bool = false, hand: [Card] = []) {
        self.name = name
        self.bankroll = bankroll
        self.isComputer = isComputer
        self.hand = hand
    }

    // Update the player's bankroll
    func updateBankroll(amount: Double) {
        bankroll += amount
    }

    // Deal cards to the player
    func dealHand(cards: [Card]) {
        hand = cards // Assign dealt cards to the player's hand
    }

    // Convert player's hand to a format suitable for Firestore
    func handAsDictionary() -> [[String: String]] {
        return hand.map { card in
            return ["rank": card.rank, "suit": card.suit]
        }
    }

    // Save player data to Firestore
    func saveToFirestore(sessionID: String) {
        let db = Firestore.firestore()
        let playerData: [String: Any] = [
            "name": name,
            "bankroll": bankroll,
            "isComputer": isComputer,
            "hand": handAsDictionary()
        ]
        
        db.collection("gameSessions").document(sessionID).collection("players").document(id.uuidString).setData(playerData) { error in
            if let error = error {
                print("Error saving player: \(error.localizedDescription)")
            } else {
                print("Player saved successfully")
            }
        }
    }

    // Initialize a player from Firestore data
    convenience init(fromData data: [String: Any]) {
        let name = data["name"] as? String ?? "Unknown"
        let bankroll = data["bankroll"] as? Double ?? 1000.0
        let isComputer = data["isComputer"] as? Bool ?? false
        let handData = data["hand"] as? [[String: String]] ?? []
        let hand = handData.map { Card(rank: $0["rank"] ?? "", suit: $0["suit"] ?? "") }
        self.init(name: name, bankroll: bankroll, isComputer: isComputer, hand: hand)
    }
}
