import UIKit
import FirebaseCore

class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Configure Firebase on app launch
        FirebaseApp.configure()
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Pause ongoing tasks or disable timers when the app moves from active to inactive
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Release shared resources and save user data as the app enters the background
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Undo changes made on entering the background
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks paused or not yet started when the app was inactive
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the app is about to terminate; save data if needed
    }
}
