import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseCrashlytics
import FirebaseFunctions
import FirebaseMessaging


struct OnlinePlayView: View {
    var numberOfHumanPlayers: Int
    var numberOfComputerPlayers: Int
    @ObservedObject var gameSession = GameSession()
    @State private var sessionID: String = "" // Keep sessionID to track sessions
    @State private var availableSessions: [String] = [] // Available sessions to join
    @State private var errorMessage: String?
    @State private var navigateToGame = false // Navigate to the actual game
    @State private var isLoading = false
    @State private var currentUser: String? = nil // Stores the current user's username
    @State private var users: [String] = [] // List of usernames to invite
    @State private var selectedUsers: Set<String> = [] // Stores selected usernames
    @State private var showInviteDialog = false // Show invite user/AI dialog
    @State private var selectedUser: String = "" // Stores selected username or AI
    @State private var aiCount: Int = 0 // Number of AI players
    @State private var maxAIPlayers: Int = 5 // Maximum number of AI players
    @State private var isDarkMode: Bool = false // Detect dark/light theme
    @State private var navigateToWaitingScreen = false // State for waiting screen navigation

    var body: some View {
        NavigationStack {
            VStack {
                Text("BIGDOOKIE Online Play")
                    .font(.largeTitle)
                    .padding()

                // Create new session button
                Button(action: createNewSession) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Create New Session")
                            .fontWeight(.bold)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isDarkMode ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                }
                .padding()

                // Join existing session by session ID
                TextField("Enter Session ID", text: $sessionID)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding()

                Button(action: joinSession) {
                    HStack {
                        Image(systemName: "arrow.right.circle.fill")
                        Text("Join Session")
                            .fontWeight(.bold)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                }
                .disabled(isLoading || sessionID.isEmpty)
                .padding()

                // Show available sessions
                Text("Available Sessions")
                    .font(.headline)
                    .padding()

                if isLoading {
                    ProgressView("Loading sessions...")
                        .padding()
                } else {
                    List(availableSessions, id: \.self) { session in
                        Button(action: {
                            sessionID = session
                            joinSession()
                        }) {
                            HStack {
                                Image(systemName: "gamecontroller.fill")
                                    .foregroundColor(.blue)
                                Text("Join session: \(session)")
                                    .font(.body)
                                    .padding(.leading, 5)
                            }
                        }
                        .padding(.vertical, 5)
                    }
                    .frame(height: 150)
                    .listStyle(PlainListStyle())
                }

                // Error message
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .padding()
                }

                Spacer()

                // Navigation to waiting screen once session is created or joined
                    .navigationDestination(isPresented: $navigateToWaitingScreen) {
                        WaitingScreenView(
                            sessionID: sessionID,
                            selectedUsers: selectedUsers,
                            gameSession: gameSession,
                            navigateToGame: $navigateToGame
                        )
                    }

            }
            .onAppear {
                loadCurrentUser()
                loadAvailableSessions()
                fetchUsersFromFirestore()
                detectTheme() // Detect dark/light theme mode
            }
            .sheet(isPresented: $showInviteDialog) {
                inviteDialog
            }
        }
    }

    // Invite dialog for choosing multiple users or AI players
    private var inviteDialog: some View {
        VStack(spacing: 15) {
            Text("Select Players to Invite")
                .font(.headline)
                .padding()

            // List of users from Firestore
            List {
                ForEach(users, id: \.self) { user in
                    Button(action: {
                        toggleUserSelection(user)
                    }) {
                        HStack {
                            Text(user)
                                .padding()
                                .background(selectedUsers.contains(user) ? Color.blue.opacity(0.2) : Color.clear) // Highlight selected rows
                                .cornerRadius(8)

                            Spacer()
                            if selectedUsers.contains(user) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.blue) // Prominent checkmark
                            }
                        }
                    }
                }
            }

            // AI Players Selection
            VStack {
                Text("Number of AI Players")
                    .font(.subheadline)
                Stepper(value: $aiCount, in: 0...maxAIPlayers) {
                    Text("AI Players: \(aiCount)")
                }
                .padding(.horizontal)
            }

            // Summary of Selected Users
            if !selectedUsers.isEmpty {
                Text("Selected Players: \(selectedUsers.joined(separator: ", "))")
                    .padding()
                    .font(.footnote)
                    .foregroundColor(.gray)
            }

            Button(action: {
                addSelectedUsersToSession()
            }) {
                Text("Invite Players")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.horizontal)

            Button(action: {
                showInviteDialog = false
            }) {
                Text("Cancel")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
        }
        .padding()
    }

    // Dark mode detection
    private func detectTheme() {
        isDarkMode = UITraitCollection.current.userInterfaceStyle == .dark
    }

    // Load current user data from Firestore
    private func loadCurrentUser() {
        if let user = Auth.auth().currentUser {
            let db = Firestore.firestore()
            let userRef = db.collection("users").document(user.uid)
            userRef.getDocument { document, error in
                if let document = document, document.exists {
                    self.currentUser = document.data()?["username"] as? String
                } else {
                    self.errorMessage = "Failed to load username."
                }
            }
        } else {
            self.errorMessage = "No logged-in user found."
        }
    }

    // Fetch users from Firestore for invitation
    private func fetchUsersFromFirestore() {
        let db = Firestore.firestore()
        db.collection("users").getDocuments { snapshot, error in
            if let error = error {
                self.errorMessage = "Error fetching users: \(error.localizedDescription)"
            } else if let snapshot = snapshot {
                self.users = snapshot.documents.map { $0.data()["username"] as? String ?? "Unknown" }
            }
        }
    }

    // Toggle user selection
    private func toggleUserSelection(_ user: String) {
        if selectedUsers.contains(user) {
            selectedUsers.remove(user)
        } else {
            selectedUsers.insert(user)
        }
    }

    // Create a new game session
    private func createNewSession() {
        guard let currentUser = currentUser else {
            self.errorMessage = "Username not available."
            return
        }

        let newSessionID = UUID().uuidString
        let db = Firestore.firestore()

        // Create the session with only the human player (no AI)
        let newSessionData: [String: Any] = [
            "sessionID": newSessionID,
            "players": [
                [
                    "name": currentUser, // Use the logged-in user's username
                    "isComputer": false,
                    "bankroll": 1000, // Initial bankroll
                    "hand": [] // Empty hand initially
                ]
            ],
            "currentTurnPlayerID": "" // Set later during gameplay
        ]

        db.collection("gameSessions").document(newSessionID).setData(newSessionData) { error in
            if let error = error {
                self.errorMessage = "Failed to create session: \(error.localizedDescription)"
            } else {
                self.sessionID = newSessionID
                showInviteDialog = true // Show dialog after session is created
            }
        }
    }

    // Add selected users and AI players to the session
    private func addSelectedUsersToSession() {
        let db = Firestore.firestore()
        let sessionRef = db.collection("gameSessions").document(sessionID)

        sessionRef.getDocument { document, error in
            if let document = document, document.exists {
                if let sessionData = document.data() {
                    var players = sessionData["players"] as? [[String: Any]] ?? []

                    // Add selected users
                    for user in selectedUsers {
                        players.append([
                            "name": user,
                            "isComputer": false,
                            "bankroll": 1000, // Initial bankroll
                            "hand": [] // Empty hand initially
                        ])
                    }

                    // Add AI players
                    for i in 0..<aiCount {
                        players.append([
                            "name": "AI Player \(i + 1)",
                            "isComputer": true,
                            "bankroll": 1000, // Initial bankroll
                            "hand": [] // Empty hand initially
                        ])
                    }

                    // Update the session with the selected users and AI players
                    sessionRef.updateData(["players": players]) { error in
                        if let error = error {
                            self.errorMessage = "Failed to update session: \(error.localizedDescription)"
                        } else {
                            navigateToWaitingScreen = true // Move to waiting screen after adding users and AI
                        }
                    }
                }
            }
        }
    }

    // Join an existing session
    private func joinSession() {
        guard let currentUser = currentUser else {
            self.errorMessage = "Username not available."
            return
        }

        let db = Firestore.firestore()
        let sessionRef = db.collection("gameSessions").document(sessionID)

        sessionRef.getDocument { document, error in
            if let document = document, document.exists {
                if let sessionData = document.data() {
                    var players = sessionData["players"] as? [[String: Any]] ?? []

                    // Add the current user to the session
                    players.append([
                        "name": currentUser,
                        "isComputer": false,
                        "bankroll": 1000, // Initial bankroll
                        "hand": [] // Empty hand initially
                    ])

                    // Update the session with the current user
                    sessionRef.updateData(["players": players]) { error in
                        if let error = error {
                            self.errorMessage = "Failed to join session: \(error.localizedDescription)"
                        } else {
                            navigateToWaitingScreen = true // Move to waiting screen after joining
                        }
                    }
                }
            } else {
                self.errorMessage = "Session not found."
            }
        }
    }

    // Load available sessions from Firestore
    private func loadAvailableSessions() {
        isLoading = true
        let db = Firestore.firestore()

        db.collection("gameSessions").getDocuments { snapshot, error in
            isLoading = false
            if let error = error {
                errorMessage = "Error loading sessions: \(error.localizedDescription)"
            } else if let snapshot = snapshot {
                availableSessions = snapshot.documents.map { $0.documentID }
            }
        }
    }
}
